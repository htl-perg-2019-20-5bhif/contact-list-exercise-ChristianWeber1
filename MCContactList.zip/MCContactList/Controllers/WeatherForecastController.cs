﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace MCApplication1.Controllers
{

    public class ContactItem
    {
        /*//[MinLength(5)]
        [MaxLength(50)]
        //[Required]
        public int id { get; set; }*/

        [MaxLength(50)]
        public string firstName { get; set; }
        
        [MaxLength(50)]
        public string lastName { get; set; }

        [MaxLength(50)]
        public string email { get; set; }
    }

    [ApiController]
    [Route("api/contacts")]
    public class ContactItemsController : ControllerBase
    {
        /*private static readonly List<TodoItem> items =
            new List<TodoItem> {
                new TodoItem { Description = "Clean my room", AssignedTo = "Me" }
            };*/

        private static readonly List<ContactItem> items =
            new List<ContactItem> {
                new ContactItem { firstName = "TestFirstname", lastName = "testLastname" , email = "testEmail" },
                new ContactItem { firstName = "TestFirstname123", lastName = "testLastname123" , email = "testEmail123" }
            };


        [HttpGet]
        public IActionResult GetAllItems()
        {
            return Ok(items);
        }

        [HttpPost]
        public IActionResult AddItem([FromBody] ContactItem newItem)
        {
            items.Add(newItem);
            return CreatedAtRoute("GetSpecificItem", new { index = items.IndexOf(newItem) }, newItem);
        }

        [HttpDelete]
        [Route("{personId}")]
        public IActionResult DeleteItem(int personId)
        {
            if (personId >= 0 && personId < items.Count)
            {
                items.RemoveAt(personId);
                return NoContent();
            }

            return BadRequest("Invalid index");
        }

        [HttpGet]
        [Route("findByName", Name = "nameFilter")]
        public IActionResult GetItem([FromQuery]string nameFilter)
        {
            for(int i = 0; i<items.Count; i++) 
            {
                if(items[i].firstName.Equals(nameFilter) || items[i].lastName.Equals(nameFilter))
                {
                    return Ok(items[i]);
                }
            }

            return BadRequest("Name not found: "+nameFilter);
        }


        /*
        [HttpGet]
        public IActionResult GetAllItems()
        {
            return Ok(items);
        }

        [HttpGet]
        [Route("{index}", Name = "GetSpecificItem")]
        public IActionResult GetItem(int index)
        {
            if (index >= 0 && index < items.Count)
            {
                return Ok(items[index]);
            }

            return BadRequest("Invalid index");
        }

        [HttpPost]
        public IActionResult AddItem([FromBody] TodoItem newItem)
        {
            items.Add(newItem);
            return CreatedAtRoute("GetSpecificItem", new { index = items.IndexOf(newItem) }, newItem);
        }

        [HttpPut]
        [Route("{index}")]
        public IActionResult UpdateItem(int index, [FromBody] TodoItem newItem)
        {
            if (index >= 0 && index < items.Count)
            {
                items[index] = newItem;
                return Ok();
            }

            return BadRequest("Invalid index");
        }
        */
    }
}
